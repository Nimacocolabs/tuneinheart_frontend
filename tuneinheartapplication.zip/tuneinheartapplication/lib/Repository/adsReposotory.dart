// import 'dart:async';
// import 'dart:convert';
//
// import 'package:tuneinheartapplication/models/adsResponse.dart';
//
// import '../serviceManager/apiProvider.dart';
//
// class CommonInfoRepository {
//   ApiProvider apiProvider;
//
//   CommonInfoRepository() {
//     apiProvider = new ApiProvider();
//   }
//
//   Future<AdsResponse> getHomeItems() async {
//     final response =
//     await apiProvider.getInstance().get("ads");
//     return AdsResponse.fromJson(response.data);
//   }
// }