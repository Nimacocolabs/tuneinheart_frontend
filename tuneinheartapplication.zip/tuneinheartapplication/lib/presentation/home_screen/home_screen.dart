import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:perfect_volume_control/perfect_volume_control.dart';
import 'package:tuneinheartapplication/Utilities/color_constant.dart';
import 'package:tuneinheartapplication/Utilities/size_utils.dart';
import 'package:tuneinheartapplication/theme/app_style.dart';
import 'package:tuneinheartapplication/widgets/radio.dart';
import 'package:http/http.dart' as http;

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List respone = [];
  var resp= "";
  bool isPlaying = false;
  double currentvol = 0.5;
  dynamic radioClass;
  bool isPlayCardVisible = false;
  dynamic currentlyPlaying;
  List stationList = [];
  List<String>? metadata;
  Map respo = {};
   List<dynamic>  listAds=[] ;
  Future getPosts() async {
    print("Get order");
    final response = await http.get(Uri.parse('https://7640-59-89-253-135.ngrok-free.app/api/ads'));
    print("Responsekjhkh${response.body}");
    var res = json.decode(response.body);
    respo= res;
    listAds = respo["ads"];
    print("0>${listAds[0]["image"]}");
    if (response.statusCode == 200) {
      _buildAdsList(listAds);
    }
    else{
      throw Exception('Failed to load post');
      print("Failed to load post");

    }
    return response;
  }

  Widget ErrorDesign() {
    return Padding(
      padding: const EdgeInsets.all(30.0),
      child: Container(
        alignment: Alignment.center,
        child: Center(
          child: const Text(
            'Kindly Connect to Internet',
            style: TextStyle(
              color:Colors.redAccent,
              fontSize: 20.0,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    print('Apicall');
    radioClass =  RadioClass();
    readJson();
    PerfectVolumeControl.hideUI = false; //set if system UI is hided or not on volume up/down
    Future.delayed(Duration.zero,() async {
      currentvol = await PerfectVolumeControl.getVolume();
      setState(() {
      });
    });

    PerfectVolumeControl.stream.listen((volume) {
      setState(() {
        currentvol = volume;
      });
    });
    super.initState();
  }
  @override
  void dispose() {
    super.dispose();

    radioClass.stop();
  }
  Future<void> readJson() async {
    final String response = await rootBundle.loadString('assets/json/station.json');
    List<dynamic> data = json.decode(response);

    setState(() {
      stationList.addAll(data);
    });
  }

  Future<void> radioPlayer(item) async {
    currentlyPlaying = item;
    radioClass.stop();

    setState(() {
      radioClass.setChannel(item);
    });

    radioClass.radioPlayer.stateStream.listen((value) {
      setState(() {
        isPlaying = value;
      });
    });

    radioClass.radioPlayer.metadataStream.listen((value) {
      setState(() {
        metadata = value;
      });
    });

    setState(() {
      isPlayCardVisible = true;
      stationList.asMap().forEach((index, items) {
        if (items == item) {
          if(item['isPlay'] == true) {
            stationList[index]['isPlay'] = false;
            radioClass.pause();
          } else {
            stationList[index]['isPlay'] = true;
            Future.delayed(
              const Duration(seconds: 1),
                  () => radioClass.play(),
            );
          }
        } else {
          stationList[index]['isPlay'] = false;
        }
      });
    });
  }

  Future<void> play() async {
    radioClass.play();
    checkStation();
  }

  Future<void> pause() async {
    radioClass.pause();
    checkStation();
  }

  void checkStation() {
    stationList.asMap().forEach((index, items) {
      if (items == currentlyPlaying) {
        if(currentlyPlaying['isPlay'] == true) {
          stationList[index]['isPlay'] = false;
          radioClass.pause();
        } else {
          stationList[index]['isPlay'] = true;
          Future.delayed(
            const Duration(seconds: 1),
                () => radioClass.play(),
          );
        }
      } else {
        stationList[index]['isPlay'] = false;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.black900,
        body: SizedBox(
          height: size.height,
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.center,
                child: SingleChildScrollView(
                  child: SizedBox(
                    height: size.height,
                    width: double.maxFinite,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: SizedBox(
                            height: size.height,
                            width: double.maxFinite,
                            child: Stack(
                              alignment: Alignment.topCenter,
                              children: [
                                Image.asset(
                                  "assets/images/background.png",
                                  alignment: Alignment.center,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top:50),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Playing  Now",
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtSFProDisplayBold30,
                                      ),
                                      Container(
                                        width: 200,
                                        margin: getMargin(
                                          top: 20,
                                        ),
                                        child: Text(
                                          "Enjoy the best top musics",
                                          maxLines: null,
                                          textAlign: TextAlign.center,
                                          style: AppStyle
                                              .txtSFProDisplayRegular16,
                                        ),
                                      ),
                                      SizedBox(height: 40,),
                                      Container(
                                         height: 400,
                                          width: 360,
                                          child: FutureBuilder(
                                              future: getPosts(),
                                              builder: (BuildContext context,snapshot) {
                                                if (snapshot.connectionState == ConnectionState.waiting) {
                                                  return Center(
                                                    child: Padding(
                                                      padding: const EdgeInsets.all(20.0),
                                                      child: CircularProgressIndicator(),
                                                    ),
                                                  );
                                                } else {
                                                  if (snapshot.hasError) {
                                                    return Container(
                                                      child: ErrorDesign(),
                                                    );
                                                  } else {
                                                    return _buildAdsList(listAds);
                                                  }
                                                }
                                              })),
                                      SizedBox(height: 20,),
                                      ElevatedButton(
                                        onPressed: (){
                                          final item = stationList![0];
                                          radioPlayer(item);
                                        },
                                        style: ElevatedButton.styleFrom(
                                            shape: const CircleBorder(),
                                            primary: ColorConstant.pink500, //button's fill color
                                            elevation: 4.0,
                                            fixedSize: const Size(60,60)
                                        ),
                                        child:  Icon(!stationList![0]['isPlay'] ? Icons.play_arrow :Icons.pause, size: 30, color: Colors.white),
                                        // Icon(Icons.play_arrow,color: ColorConstant.whiteA700,size: 30,)
                                      ),
                                      SizedBox(height: 10,),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(Icons.volume_down,color: ColorConstant.whiteA700,),
                                          SizedBox(
                                            width: 240,
                                            child: Slider(
                                              activeColor: Colors.pink,
                                              value: currentvol,
                                              onChanged: (newvol){
                                                currentvol = newvol;
                                                PerfectVolumeControl.setVolume(newvol); //set new volume
                                                setState(() {
                                                });
                                              },
                                              min: 0, //
                                              max:  3,
                                              divisions:400,
                                            ),
                                          ),
                                          Icon(Icons.volume_up,color: ColorConstant.whiteA700),
                                        ],
                                      ),
                                      SizedBox(height: 40,)
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAdsList(List adsList) {
    return CarouselSlider.builder(
        itemCount: adsList.length,
        options: CarouselOptions(
            autoPlay: true,
            aspectRatio: 1 / (5 / 3),
            enableInfiniteScroll: false,
            enlargeCenterPage: true,
            viewportFraction: 1
        ),
        itemBuilder: (context, index, realIdx) {
          return CachedNetworkImage(
            fit: BoxFit.fill,
            imageUrl: adsList[index]["image"],
            placeholder:
                (context, url) =>
                Center(
                  child:
                  CircularProgressIndicator(),
                ),
            errorWidget:
                (context, url, error) =>
                ClipRRect(
                  borderRadius:
                  BorderRadius.circular(
                      12),
                  child: Image(
                    image: AssetImage(
                        'assets/images/dp.png'),
                    // height: 60,
                    // width: 60,
                  ),
                ),
          );
        });
  }


}
