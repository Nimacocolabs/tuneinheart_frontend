package com.example.tuneinheartapplication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
